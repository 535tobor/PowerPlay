package org.firstinspires.ftc.teamcode;
import com.qualcomm.robotcore.eventloop.opmode.Autonomous;
import com.qualcomm.robotcore.hardware.DcMotor;

@Autonomous
public class AutoMode extends HardwareMapLinear{
    @Override
    public void runOpMode() {
        initHwMap();
        waitForStart();


        if (opModeIsActive()) {
            zone3();



        }
    }
}
