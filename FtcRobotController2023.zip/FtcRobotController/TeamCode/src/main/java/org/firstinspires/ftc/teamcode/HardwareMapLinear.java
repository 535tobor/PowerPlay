package org.firstinspires.ftc.teamcode;

import com.qualcomm.hardware.bosch.BNO055IMU;
import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.util.ElapsedTime;


public class HardwareMapLinear extends LinearOpMode {
    public DcMotor motorFrontLeft, motorFrontRight, motorBackLeft, motorBackRight, shaft;
    public ElapsedTime runtime = new ElapsedTime();
    public BNO055IMU imu;

    public void initHwMap() {
        motorFrontLeft = hardwareMap.dcMotor.get("fl");
        motorBackLeft = hardwareMap.dcMotor.get("bl");
        motorFrontRight = hardwareMap.dcMotor.get("fr");
        motorBackRight = hardwareMap.dcMotor.get("br");
        shaft = hardwareMap.dcMotor.get("shaft");
        shaft.setMode(DcMotor.RunMode.STOP_AND_RESET_ENCODER);


        //shaft = hardwareMap.dcMotor.get("shaft");

        motorFrontRight.setDirection(DcMotor.Direction.REVERSE);
        motorBackRight.setDirection(DcMotor.Direction.REVERSE);

        BNO055IMU.Parameters parameters = new BNO055IMU.Parameters();
        // Technically this is the default, however specifying it is clearer
        parameters.angleUnit = BNO055IMU.AngleUnit.RADIANS;
        imu = hardwareMap.get(BNO055IMU.class, "imu");
        // Without this, data retrieving from the IMU throws an exception
        imu.initialize(parameters);
    }

    @Override
    public void runOpMode() {
    }

    public void setPowerAll(double speed) {
        motorBackLeft.setPower(-speed);
        motorBackRight.setPower(-speed);
        motorFrontRight.setPower(-speed);
        motorFrontLeft.setPower(-speed);
    }
    public void setPowerAllZero() {
        motorBackLeft.setPower(0);
        motorBackRight.setPower(0);
        motorFrontRight.setPower(0);
        motorFrontLeft.setPower(0);
    }
    public void turnRight(double power){
        motorBackLeft.setPower(-power);
        motorBackRight.setPower(power);
        motorFrontRight.setPower(power);
        motorFrontLeft.setPower(-power);
    }
    public void turnLeft(double power){
        motorBackLeft.setPower(power);
        motorBackRight.setPower(-power);
        motorFrontRight.setPower(-power);
        motorFrontLeft.setPower(power);
    }
    public void strafeLeft(double power, double time){
        runtime.reset();
        while (opModeIsActive() && runtime.time() < time){
            motorBackLeft.setPower(-power);
            motorBackRight.setPower(power);
            motorFrontRight.setPower(-power);
            motorFrontLeft.setPower(power);
        }
        setPowerAllZero();
    }
    public void strafeRight(double power, double time){
        runtime.reset();
        while (opModeIsActive() && runtime.time() < time){
            motorBackLeft.setPower(power);
            motorBackRight.setPower(-power);
            motorFrontRight.setPower(power);
            motorFrontLeft.setPower(-power);
        }
        setPowerAllZero();
    }
    public void turn(double degrees){
        double turnAmountRadians = (degrees*(Math.PI/180));
        double objAngle = -imu.getAngularOrientation().firstAngle + turnAmountRadians;

        if (turnAmountRadians > 0){
            while (-imu.getAngularOrientation().firstAngle <= objAngle){
                turnRight(.4);
            }
        }
        if (turnAmountRadians < 0){
            while (-imu.getAngularOrientation().firstAngle >= objAngle){
                turnLeft(.4);
            }
        }
        setPowerAllZero();
    }
    public void zone1(){
        driveByTime(.6, 1.1);
        strafeLeft(.6, 1.4);

    }
    public void zone2(){
        driveByTime(.6, 1.1);
    }
    public void zone3(){
        driveByTime(.6,1.1);
        strafeRight(.6,1.4);
    }


    public void driveByTime(double speed, double time) {
        runtime.reset();
        while (opModeIsActive() && runtime.time() < time) {
            setPowerAll(speed);
        }
        setPowerAll(0.0);

    }
}
