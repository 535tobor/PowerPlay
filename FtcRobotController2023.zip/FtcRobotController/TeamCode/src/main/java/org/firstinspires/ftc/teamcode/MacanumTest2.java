package org.firstinspires.ftc.teamcode;


import com.qualcomm.robotcore.eventloop.opmode.LinearOpMode;
import com.qualcomm.robotcore.eventloop.opmode.TeleOp;
import com.qualcomm.robotcore.hardware.DcMotor;
import com.qualcomm.robotcore.hardware.DcMotorSimple;
import com.qualcomm.hardware.bosch.BNO055IMU;
@TeleOp
public class MacanumTest2 extends HardwareMapIter {
    @Override
    public void init(){
        initHwMap2();
        // Retrieve the IMU from the hardware map
        BNO055IMU imu = hardwareMap.get(BNO055IMU.class, "imu");
        BNO055IMU.Parameters parameters = new BNO055IMU.Parameters();
        // Technically this is the default, however specifying it is clearer
        parameters.angleUnit = BNO055IMU.AngleUnit.RADIANS;
        // Without this, data retrieving from the IMU throws an exception
        imu.initialize(parameters);


    }
    @Override
    public void init_loop(){

    }
    @Override
    public void start(){

    }
    @Override
    public void loop(){

        double y = gamepad1.left_stick_y; // Remember, this is reversed!
        double x = -gamepad1.left_stick_x * 1.1; // Counteract imperfect strafing
        double rx = -gamepad1.right_stick_x;

        // Read inverse IMU heading, as the IMU heading is CW positive

        double botHeading = -imu.getAngularOrientation().firstAngle;

        double rotX = x * Math.cos(botHeading) - y * Math.sin(botHeading);
        double rotY = x * Math.sin(botHeading) + y * Math.cos(botHeading);

        // Denominator is the largest motor power (absolute value) or 1
        // This ensures all the powers maintain the same ratio, but only when
        // at least one is out of the range [-1, 1]
        double denominator = Math.max(Math.abs(y) + Math.abs(x) + Math.abs(rx), 1);
        double frontLeftPower = (rotY + rotX + rx) / denominator;
        double backLeftPower = (rotY - rotX + rx) / denominator;
        double frontRightPower = (rotY - rotX - rx) / denominator;
        double backRightPower = (rotY + rotX - rx) / denominator;

        if (gamepad1.left_trigger > .2){
            motorFrontLeft.setPower(.3 * frontLeftPower);
            motorBackLeft.setPower(.3 * backLeftPower);
            motorFrontRight.setPower(.3 * frontRightPower);
            motorBackRight.setPower(.3 * backRightPower);
        }
        else{
            motorFrontLeft.setPower(.8 * frontLeftPower);
            motorBackLeft.setPower(.8 * backLeftPower);
            motorFrontRight.setPower(.8 * frontRightPower);
            motorBackRight.setPower(.8 * backRightPower);
        }

        if (gamepad2.dpad_up){shaft.setPower(-1);}
        else if ((gamepad2.dpad_down)&(shaft.getCurrentPosition() < -5) ){shaft.setPower(1);}
        else {
            if ((shaft.getCurrentPosition() < -5) & (shaft.getCurrentPosition() > -2800)){shaft.setPower(-.01);}
            else{shaft.setPower(0.0);}
        }
        if (gamepad2.y){
            shaft.setPower(1);
        }
        else if (gamepad2.a){
            shaft.setPower(-1);
        }

        telemetry.addData("Rotation", botHeading/3.14159);
        telemetry.addData("shaft position: ", shaft.getCurrentPosition());
    }

}
